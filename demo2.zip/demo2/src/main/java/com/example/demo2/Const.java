package com.example.demo2;

public class Const {
    public static final String USER_TABLE = "users";
    public static final String USERS_ID = "id";
    public static final String USERS_NAME = "name";
    public static final String USERS_SURNAME = "surname";
    public static final String USERS_LOGIN = "login";
    public static final String USERS_PASS = "pass";
    public static final String USERS_GENDER = "gender";
}
